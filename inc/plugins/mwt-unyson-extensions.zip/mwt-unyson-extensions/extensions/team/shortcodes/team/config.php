<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Team', 'fw' ),
		'description' => esc_html__( 'Team various views', 'fw' ),
		'tab'         => esc_html__( 'Widgets', 'fw' )
	)
);