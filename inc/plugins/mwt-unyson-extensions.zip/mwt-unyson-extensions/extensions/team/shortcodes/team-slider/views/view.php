<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
/**
 * @var array $atts
 * @var array $posts
 */

$unique_id = uniqid();

$categories = fw_ext_extension_get_listing_categories( $atts['cat'], 'team' );
$sort_classes = fw_ext_extension_get_sort_classes( $posts->posts, $categories, '', 'team' );
?>

<div class="team-slider-shortcode">
	<?php
		$i = 1;
		while ( $posts->have_posts() ) : $posts->the_post();

		$itemClass = ( $i % 2  == 0 ) ? 'fadeInRight from-right' : 'fadeInLeft from-left';

		$ext_team_settings = fw()->extensions->get( 'team' )->get_settings();
		$taxonomy_name = $ext_team_settings['taxonomy_name'];

		$pID = get_the_ID();
		$post_atts = fw_get_db_post_option($pID);

		?>
        <div class="team-slider-item<?php echo ( $i === 1 ) ? ' active' : ''; ?>">

            <div class="team-slider-image animated <?php echo esc_attr( $itemClass ); ?>">
	            <?php
	            $pID = get_the_ID();
	            $atts = fw_get_db_post_option( $pID );
	            $full_image_src = ($atts['slider_image']['url']) ? $atts['slider_image']['url'] : '' ;
	            $unique_id = uniqid();
	            ?>
                <img src="<?php echo esc_url( $full_image_src ); ?>" alt="<?php echo esc_attr( $full_image_src ); ?>">
            </div>
			<div class="team-slider-name">

				<h3 class="slide-title">
					<span>
						<?php the_title(); ?>
					</span>
				</h3>

			</div><!-- eof .team-slider-name -->

		</div><!-- eof .team-slider-item -->

	<?php
		$i++;
		endwhile; ?>
	<?php wp_reset_postdata(); // reset the query ?>
</div>