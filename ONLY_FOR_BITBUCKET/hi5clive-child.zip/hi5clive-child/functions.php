<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if ( !function_exists( 'hi5clive_child_cfg_parent_css' ) ):
	function hi5clive_child_cfg_parent_css() {

		wp_deregister_style( 'hi5clive-main' );
		wp_enqueue_style( 'hi5clive-child-main', get_theme_file_uri( '/css/main.css' ), array(), HI5CLIVE_THEME_VERSION );
	}
endif;
add_action( 'wp_enqueue_scripts', 'hi5clive_child_cfg_parent_css', 999 );

// END ENQUEUE PARENT ACTION