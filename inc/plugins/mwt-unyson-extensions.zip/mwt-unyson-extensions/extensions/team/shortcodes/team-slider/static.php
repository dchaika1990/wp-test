<?php if (!defined('FW')) die('Forbidden');

$shortcodes_extension = fw_ext('team');
wp_enqueue_script(
	'theme-team-slider-shortcode',
	$shortcodes_extension->get_declared_URI( '/shortcodes/team-slider/static/js/scripts.js' ),
	array(),
	false,
	true
);